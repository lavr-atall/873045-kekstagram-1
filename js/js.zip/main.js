import { mockPhotos } from './data.js';
window.console.log (mockPhotos);
