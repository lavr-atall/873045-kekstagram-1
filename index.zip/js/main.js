import { mockPhotos } from './mock-photos-generator.js';
window.console.log (mockPhotos);
